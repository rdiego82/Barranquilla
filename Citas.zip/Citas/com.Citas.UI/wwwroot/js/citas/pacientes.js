﻿(function () {
    this.Pacientes = this.Pacientes || {};
    var ns = this.Pacientes;

    //Mostrar cuadro de dialogo de Pacientes
    ns.addEditPaciente = function () {
        $("#dlgPacientes").modal("show");
    }

    //Ocultar cuadro de diálogo de Pacientes
    ns.cancelarPaciente = function () {
        Pacientes.reestablecerFormularioPaciente();
    }

    //Permitir únicamente números en la caja de texto
    ns.Numeros = function (e) {
        var key = window.Event ? e.which : e.keyCode
        return ((key >= 48 && key <= 57) || (key == 8))
    }

    //Guardar nuevo Paciente
    ns.guardarPaciente = function () {
        var txtIdentificacion = $("#txtDlgIdentificacion").val();
        var txtNombre = $("#txtDlgNombre").val();
        var txtEdad = $("#txtDlgEdad").val();
        var selSexo = $("select[name=selSexoPaciente]").val();

        if (txtIdentificacion && txtNombre && txtEdad) {

            var paciente = { Id: txtIdentificacion, Nombre: txtNombre, Edad: txtEdad, Sexo: selSexo };

            var d = $.Deferred();
            setTimeout(function () {
                $("#dlgEspera").modal("show");

                $.ajax({
                    type: "POST",
                    url: "/api/Pacientes",
                    dataType: "json",
                    contentType: 'application/json; charset=utf-8',
                    success: function (pacResul) {
                        if (pacResul) {
                            d.resolve();
                            $("#dlgEspera").modal("hide");
                            
                            alert("Paciente almacenado correctamente.",
                                {
                                    label: "Aceptar",
                                    success: function () {
                                        console.log("aceptar");
                                    }
                                }
                            );

                            Pacientes.reestablecerFormularioPaciente();
                           
                        }
                        else {
                            $("#dlgEspera").modal("hide");
                            alert("Se presentó un error al almacenar la información del paciente. Por favor vuelva a intentarlo.",
                                {
                                    label: "Aceptar",
                                    success: function () {
                                        console.log("aceptar");
                                    }
                                }
                            );
                            d.reject();
                        }

                    },
                    error: function (request, status, error) {
                        $("#dlgEspera").modal("hide");
                        alert("Se presentó un error al almacenar la información del paciente. Por favor vuelva a intentarlo.",
                            {
                                label: "Aceptar",
                                success: function () {
                                    console.log("aceptar");
                                }
                            }
                        );
                        d.reject();
                    },
                    data: JSON.stringify(paciente)
                });

                d.resolve();

            }, 0);
            return d.promise();

        } else {

            alert("Por favor ingrese todos los datos del Paciente.",
                {
                    label: "Aceptar",
                    success: function () {
                        console.log("aceptar");
                    }
                }

            );
        }

    }


    //consultar Pacientes
    ns.consultarPacientes = function () {
        var d = $.Deferred();
        setTimeout(function () {
            $("#dlgEspera").modal("show");
            $("#pacLst").empty();

            $.get("/api/Pacientes", function (pacLst) {
                $("#dlgEspera").modal("hide");

                if (pacLst) {
                    //Pacientes.guardarDatosLS(pacLst);

                    var tabla = "<table class='table table-bordered table-striped table-condensed'><thead><tr><th>Identificaci&oacute;n del Paciente</th><th>Nombre</th>" +
                        "<th>Edad</th><th>Sexo</th></tr></thead><tbody>";

                    for (var i = 0; i < pacLst.length; i++) {
                        tabla = tabla + "<tr><td>" + pacLst[i].id + "</td><td> " + pacLst[i].nombre + "</td><td> " + pacLst[i].edad + "</td><td>" + pacLst[i].sexo + "</td></tr>";
                    }

                    tabla = tabla + "</tbody></table>";
                    $("#pacLst").append(tabla);
                    d.resolve();
                }
                else
                    d.resolve();
            }).fail(function () {
                $("#dlgEspera").modal("hide");
                alert("Se presentó un error al consultar la información, por favor vuelva a intentarlo..",
                    {
                        label: "Aceptar",
                        success: function () {
                            console.log("aceptar");
                        }
                    }
                );
                d.reject();
            });
        }, 0);
        return d.promise();
    }    

    //Guardar y recuperar datos del Paciente en localStorage
    ns.guardarDatosLS = function(lstPacientes){
        localStorage.pacientesLst = lstPacientes;
    }

    ns.recuperarDatosLS = function() {
        if (localStorage.pacientesLst != undefined) {
            return localStorage.pacientesLst;
        }
    }

    //limpiar Controles del formulario Paciente
    ns.reestablecerFormularioPaciente = function (e) {
        $("#txtDlgIdentificacion").val("");
        $("#txtDlgNombre").val("");
        $("#txtDlgEdad").val("");
        $("#dlgPacientes").modal("hide");
    }


}());

