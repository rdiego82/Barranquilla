﻿(function () {
    this.Citas = this.Citas || {};
    var ns = this.Citas;

    //Mostrar cuadro de dialogo de Pacientes
    ns.addEditPaciente = function(){
        $("#dlgPacientes").modal("show");
    }

    //Ocultar cuadro de diálogo de Pacientes
    ns.cancelarPaciente = function(){
        $("#dlgPacientes").modal("hide");
    }

    //Permitir únicamente números en la caja de texto
    ns.Numeros = function(e){
        var key = window.Event ? e.which : e.keyCode
        return ((key >= 48 && key <= 57) || (key == 8))
    }

    //Guardar nuevo Cita
    ns.guardarCita = function () {
        var txtIdentificacion = $("#txtCitaIdentificacion").val();
        var txtNombre = $("#txtCitaNombre").val();
        var dtFecha = $("#dtCitaFecha").val();
        var selTipoCita = $("select[name=selCitaTipo]").val();
        var now = new Date();

        if (!dtFecha) {
            alert("Por favor reviar la fecha de la cita. Ingrese una hora válida.",
                {
                    label: "Aceptar",
                    success: function () {
                        console.log("aceptar");
                    }
                }
            );

            return false;
        }

        var fecha1 = moment(dtFecha);
        var fecha2 = moment(now);

        var diff = fecha1.diff(fecha2, 'h'); // Diferencia en horas
       
        if (diff < 24) {
            alert("Las citas se deben agendar con mínimo 24 horas de antelación. Por favor reviar la fecha y hora de la cita.",
                {
                    label: "Aceptar",
                    success: function () {
                        console.log("aceptar");
                    }
                }
            );
        } else {

            if (txtIdentificacion && txtNombre && dtFecha) {

                var cita = { PacienteId: txtIdentificacion, Fecha: dtFecha, TipoCitaId: selTipoCita };

                var d = $.Deferred();
                setTimeout(function () {
                    $("#dlgEspera").modal("show");

                    $.ajax({
                        type: "POST",
                        url: "/api/Citas",
                        dataType: "json",
                        contentType: 'application/json; charset=utf-8',
                        success: function (citaResul) {
                            if (citaResul) {
                                d.resolve();
                                $("#dlgEspera").modal("hide");

                                alert("Cita almacenada correctamente.",
                                    {
                                        label: "Aceptar",
                                        success: function () {
                                            console.log("aceptar");
                                        }
                                    }
                                );

                                Citas.reestablecerFormularioCita();
                            }
                            else {
                                $("#dlgEspera").modal("hide");
                                alert("Se presentó un error al almacenar la información de la cita. Por favor vuelva a intentarlo y verifique que exista el paciente.",
                                    {
                                        label: "Aceptar",
                                        success: function () {
                                            console.log("aceptar");
                                        }
                                    }
                                );
                                d.reject();
                            }
                        },
                        error: function (request, status, error) {
                            $("#dlgEspera").modal("hide");
                            alert("Se presentó un error al almacenar la información de la cita. Por favor vuelva a intentarlo y verifique que exista el paciente.",
                                {
                                    label: "Aceptar",
                                    success: function () {
                                        console.log("aceptar");
                                    }
                                }
                            );
                            d.reject();
                        },
                        data: JSON.stringify(cita)
                    });
                    d.resolve();
                }, 0);

                return d.promise();

            } else {
                alert("Por favor ingrese todos los datos de la Cita.",
                    {
                        label: "Aceptar",
                        success: function () {
                            console.log("aceptar");
                        }
                    }
                );
            }
        }
    }


    //consultar Citas
    ns.consultarCitas = function () {
        var d = $.Deferred();
        setTimeout(function () {
            $("#dlgEspera").modal("show");
            $("#citLst").empty();

            $.get("/api/Citas", function (citasLst) {
                $("#dlgEspera").modal("hide");

                if (citasLst) {
                    var tabla = "<table class='table table-bordered table-striped table-condensed'><thead><tr><th>Identificaci&oacute;n del Paciente</th><th>tipo de Cita</th>" +
                        "<th>Fecha</th></tr></thead><tbody>";

                    for (var i = 0; i < citasLst.length; i++) {
                        tabla = tabla + "<tr><td>" + citasLst[i].pacienteId + "</td><td> " + citasLst[i].tipoCitaId + "</td><td> " + citasLst[i].fecha + "</td></tr>";
                    }

                    tabla = tabla + "</tbody></table>";
                    $("#citLst").append(tabla);
                    d.resolve();
                }
                else
                    d.resolve();
            }).fail(function () {
                $("#dlgEspera").modal("hide");
                alert("Se presentó un error al consultar la información, por favor vuelva a intentarlo..",
                    {
                        label: "Aceptar",
                        success: function () {
                            console.log("aceptar");
                        }
                    }
                );
                d.reject();
            });
        }, 0);
        return d.promise();
    }    
    
    //limpiar Controles del formulario Paciente
    ns.reestablecerFormularioCita = function (e) {
        $("#txtCitaIdentificacion").val("");
        $("#txtCitaNombre").val("");
        $("#dtCitaFecha").val("");
        $("#dlgPacientes").modal("hide");
    }

    //Consultar si un paciente ya tiene asignada una cita para el mismo día
    ns.ConsultarPacienteCita = function(identificacion){
        if (localStorage.pacientesLst != undefined) {
            var pacientesLst = localStorage.pacientesLst;
            var now = new Date();
            var fecha = moment(now);

            for (var i = 0; i < pacientesLst.length; i++) {
                if (identificacion == pacientesLst[i].id) {
                    var fechaCita = moment(pacientesLst[i].fecha);

                    if (fechaCita.diff(fecha, 'h') < 24) {
                        alert("Se presentó un error al consultar la información, por favor vuelva a intentarlo..",
                            {
                                label: "Aceptar",
                                success: function () {
                                    console.log("aceptar");
                                }
                            }
                        );

                        return false;
                    }
                }
            }
        }
    }

}());

