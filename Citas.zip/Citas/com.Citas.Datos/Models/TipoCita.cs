﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace com.Citas.Datos.Models
{
    public class TipoCita
    {
        public int Id { get; set; }
        public string Descripcion { get; set; }
        public List<Cita> Cita { get; set; }
    }
}
