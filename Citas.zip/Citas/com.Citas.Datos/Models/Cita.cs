﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace com.Citas.Datos.Models
{
    public class Cita
    {
        public int Id { get; set; }
        public int? PacienteId { get; set; }
        public DateTime? Fecha { get; set; }
        public int? TipoCitaId { get; set; }

        public Paciente Paciente { get; set; }
        public TipoCita TipoCita { get; set; }
    }
}
