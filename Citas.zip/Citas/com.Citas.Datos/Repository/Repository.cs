﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Linq.Expressions;
using System.Data;
using com.Citas.Datos.Data;
using Microsoft.EntityFrameworkCore;

namespace com.Citas.Datos.Repository
{
    /// <summary>
    /// Repositorio genérico
    /// </summary>
    /// <typeparam name="TObject"></typeparam>
    public class Repository<TObject> : IRepository<TObject> where TObject : class
    {
        protected CitaDbContext Context = null;

        /// <summary>
        /// Constructor de clase
        /// </summary>
        /// <param name="context">Contexto específico del proyecto</param>
        public Repository(CitaDbContext context)
        {
            Context = context;
        }

        /// <summary>
        /// Propiedad que devuelve una instancia DbSet del tipo TObject dado
        /// </summary>
        protected DbSet<TObject> DbSet
        {
            get
            {
                return Context.Set<TObject>();
            }
        }

        /// <summary>
        /// Devuelve un conjunto de registros filtrado por la expresión indicada en el parámetro
        /// </summary>
        /// <param name="predicate">Expresión de filtrado</param>
        /// <returns></returns>
        protected IQueryable<TObject> Filter(Expression<Func<TObject, bool>> predicate)
        {
            return DbSet.Where(predicate).AsQueryable<TObject>();
        }

        /// <summary>
        /// Liberación de recursos
        /// </summary>
        public void Dispose()
        {
            if (Context != null)
                Context.Dispose();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public virtual List<TObject> Consultar()
        {
            return DbSet.ToList();
        }

        /// <summary>
        /// Devuelve el primer registro que satisfaga la expresión de búsqueda pasada como parámetro
        /// </summary>
        /// <param name="predicate">Expresión de búsqueda</param>
        /// <returns></returns>
        public virtual TObject Consultar(Expression<Func<TObject, bool>> predicate)
        {
            return DbSet.FirstOrDefault(predicate);
        }

        /// <summary>
        /// Añade la entidad pasada como parámetro al contexto, guardando los cambios
        /// </summary>
        /// <param name="TObject">El objeto a añadir al contexto</param>
        /// <returns></returns>
        public virtual bool Crear(TObject TObject)
        {
            var newEntry = DbSet.Add(TObject);
            return Context.SaveChanges() == 1 ? true : false;
        }

        /// <summary>
        /// Actualiza el objeto pasado como parámetro con sus valores en el contexto, guardando los cambios
        /// </summary>
        /// <param name="TObject">El objeto con los nuevos valores</param>
        /// <returns></returns>
        public virtual bool Actualizar(TObject TObject)
        {
            var entry = Context.Entry(TObject);
            DbSet.Attach(TObject);
            entry.State = EntityState.Modified;
            return Context.SaveChanges() == 1 ? true : false; 
        }

        /// <summary>
        /// Elimina los objetos del contexto que satisfagan la condición de búsqueda pasada como parámetro, guardando los cambios
        /// </summary>
        /// <param name="predicate">Condición de búsqueda</param>
        /// <returns></returns>
        public virtual bool Eliminar(TObject TObject)
        {
            var entry = Context.Entry(TObject);
            DbSet.Attach(TObject);
            entry.State = EntityState.Deleted;
            return Context.SaveChanges() == 1 ? true : false;
        }
    }
}
