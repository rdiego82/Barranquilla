﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using com.Citas.Datos.Models;
using com.Citas.Entidades;
using com.Citas.Datos.Data;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;


namespace com.Citas.Datos.Repository
{
    public class CitaDatos
    {
        static List<Cita> CitasList = new List<Cita>();

        /// <summary>
        /// 
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        public List<Cita> Consultar()
        {
            using (var dataContext = new CitaDbContext())
            {
                var citaRepository = new Repository<Cita>(dataContext);
                CitasList = citaRepository.Consultar();
            }
            return CitasList;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        public Cita Consultar(string key)
        {
            Cita cita = new Cita();

            using (var dataContext = new CitaDbContext())
            {
                var citaRepository = new Repository<Cita>(dataContext);

                cita = citaRepository
                    .Consultar(c => c.Fecha.Equals(key));
            }
            return cita;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cita"></param>
        public bool Crear(Cita cita)
        {
            bool resultado;
            using (var dataContext = new CitaDbContext())
            {
                var citaRepository = new Repository<Cita>(dataContext);
                resultado = citaRepository.Crear(cita);
            }
            return resultado;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cita"></param>
        /// <returns></returns>
        public bool Actualizar(Cita cita)
        {
            bool resultado = false;
            using (var dataContext = new CitaDbContext())
            {
                var citaRepository = new Repository<Cita>(dataContext);
                resultado = citaRepository.Actualizar(cita);
            }
            return resultado;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cita"></param>
        public bool Eliminar(Cita cita)
        {
            bool resultado = false;
            using (var dataContext = new CitaDbContext())
            {
                var citaRepository = new Repository<Cita>(dataContext);
                resultado = citaRepository.Eliminar(cita);
            }
            return resultado;
        }
    }

}
