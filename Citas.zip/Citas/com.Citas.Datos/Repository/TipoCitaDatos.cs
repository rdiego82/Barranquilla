﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using com.Citas.Datos.Models;
using com.Citas.Entidades;
using com.Citas.Datos.Data;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace com.Citas.Datos.Repository
{
    public class TipoCitaDatos
    {
        static List<TipoCita> TipoCitasList = new List<TipoCita>();

        /// <summary>
        /// 
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        public List<TipoCita> Consultar()
        {
            using (var dataContext = new CitaDbContext())
            {
                var tipoCitaRepository = new Repository<TipoCita>(dataContext);

                TipoCitasList = tipoCitaRepository.Consultar();
            }

            return TipoCitasList;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        public TipoCita Consultar(string key)
        {
            TipoCita tipocita = new TipoCita();

            using (var dataContext = new CitaDbContext())
            {
                var tipoCitaRepository = new Repository<TipoCita>(dataContext);

                tipocita = tipoCitaRepository
                    .Consultar(c => c.Descripcion.StartsWith(key));
            }
            return tipocita;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="tipoCita"></param>
        public bool Crear(TipoCita tipoCita)
        {
            bool resultado;

            using (var dataContext = new CitaDbContext())
            {
                var tipoCitaRepository = new Repository<TipoCita>(dataContext);
                resultado = tipoCitaRepository.Crear(tipoCita);
            }
            return resultado;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="tipoCita"></param>
        /// <returns></returns>
        public bool Actualizar(TipoCita tipoCita)
        {
            bool resultado = false;
            using (var dataContext = new CitaDbContext())
            {
                var pacienteRepository = new Repository<TipoCita>(dataContext);
                resultado = pacienteRepository.Actualizar(tipoCita);
            }
            return resultado;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="tipoCita"></param>
        public bool Eliminar(TipoCita tipoCita)
        {
            bool resultado = false;
            using (var dataContext = new CitaDbContext())
            {
                var pacienteRepository = new Repository<TipoCita>(dataContext);
                resultado = pacienteRepository.Eliminar(tipoCita);
            }
            return resultado;
        }
    }
}
