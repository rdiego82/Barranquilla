﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using com.Citas.Datos.Models;
using com.Citas.Entidades;
using com.Citas.Datos.Data;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace com.Citas.Datos.Repository
{
    public class PacienteDatos
    {
        static List<Paciente> PacientesList = new List<Paciente>();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public List<Paciente> Consultar()
        {
            using (var dataContext = new CitaDbContext())
            {
                var pacienteRepository = new Repository<Paciente>(dataContext);

                PacientesList = pacienteRepository.Consultar();
            }

            return PacientesList;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public Paciente Consultar(string key)
        {
            Paciente paciente = new Paciente();

            using (var dataContext = new CitaDbContext())
            {
                var pacienteRepository = new Repository<Paciente>(dataContext);

                paciente = pacienteRepository
                    .Consultar(c => c.Nombre.StartsWith(key));
            }
            return paciente;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="item"></param>
        public bool Crear(Paciente paciente)
        {
            bool resultado;

            using (var dataContext = new CitaDbContext())
            {
                var pacienteRepository = new Repository<Paciente>(dataContext);
                resultado = pacienteRepository.Crear(paciente);
            }
            return resultado;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="paciente"></param>
        /// <returns></returns>
        public bool Actualizar(Paciente paciente)
        {
            bool resultado = false;
            using(var dataContext = new CitaDbContext())
            {
                var pacienteRepository = new Repository<Paciente>(dataContext);
                resultado = pacienteRepository.Actualizar(paciente);
            }
            return resultado;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="paciente"></param>
        public bool Eliminar(Paciente paciente)
        {
            bool resultado = false;
            using (var dataContext = new CitaDbContext())
            {
                var pacienteRepository = new Repository<Paciente>(dataContext);
                resultado = pacienteRepository.Eliminar(paciente);
            }
            return resultado;
        }
    }
}
