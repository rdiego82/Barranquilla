﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Linq.Expressions;


namespace com.Citas.Datos.Repository
{
    public interface IRepository<T> : IDisposable where T : class
    {
        List<T> Consultar();

        /// Encuentra un objeto por la expresión indicada
        T Consultar(Expression<Func<T, bool>> predicate);

        /// Crea un nuevo objeto en la base de datos
        ///Nuevo objeto a crear
        bool Crear(T t);

        /// Actualiza los cambios del objeto en la base de datos
        ///Objeto a actualizar
        bool Actualizar(T t);

        /// Borra objetos de la base de datos en base a una expresión de filtrado
        bool Eliminar(T t);
    }
}
