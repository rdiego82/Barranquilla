﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using com.Citas.Datos.Data;

namespace com.Citas.Datos.Migrations
{
    [DbContext(typeof(CitaDbContext))]
    [Migration("20171015141909_InitialCreate")]
    partial class InitialCreate
    {
        protected override void BuildTargetModel(ModelBuilder modelBuilder)
        {
            modelBuilder
                .HasAnnotation("ProductVersion", "1.1.3")
                .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            modelBuilder.Entity("com.Citas.Datos.Models.Cita", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<DateTime?>("Fecha");

                    b.Property<int?>("PacienteId");

                    b.Property<int?>("TipoCitaId");

                    b.HasKey("Id");

                    b.HasIndex("PacienteId");

                    b.HasIndex("TipoCitaId");

                    b.ToTable("Cita");
                });

            modelBuilder.Entity("com.Citas.Datos.Models.Paciente", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<int?>("Edad");

                    b.Property<string>("Nombre");

                    b.Property<string>("Sexo");

                    b.HasKey("Id");

                    b.ToTable("Paciente");
                });

            modelBuilder.Entity("com.Citas.Datos.Models.TipoCita", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Descripcion");

                    b.HasKey("Id");

                    b.ToTable("TipoCita");
                });

            modelBuilder.Entity("com.Citas.Datos.Models.Cita", b =>
                {
                    b.HasOne("com.Citas.Datos.Models.Paciente", "Paciente")
                        .WithMany("Cita")
                        .HasForeignKey("PacienteId");

                    b.HasOne("com.Citas.Datos.Models.TipoCita", "TipoCita")
                        .WithMany("Cita")
                        .HasForeignKey("TipoCitaId");
                });
        }
    }
}
