﻿using com.Citas.Datos.Models;
using com.Citas.Datos.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace com.Citas.Datos.Data
{
    public class CitaContextInitialize
    {
        private CitaDbContext _ctx;

        public CitaContextInitialize(CitaDbContext ctx)
        {
            _ctx = ctx;
        }

        /// <summary>
        /// 
        /// </summary>
        public void InitializeData()
        {
            if (_ctx.Database.EnsureCreated())
            {
                Seed();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private void Seed()
        {
            
            if (_ctx.Paciente.Count() == 0)
            {
                // Creación de Pacientes
                var Pacientes = new List<Paciente>{
                    new Paciente{Nombre = "Juan", Edad=32, Sexo="M"},
                    new Paciente{Nombre = "Manuel", Edad=39, Sexo="M"},
                    new Paciente{Nombre = "Felipe", Edad=49, Sexo="M"},
                    new Paciente{Nombre = "Jair", Edad=17, Sexo="M"},
                    new Paciente{Nombre = "Andrés", Edad=21, Sexo="M"},
                };

                Pacientes.ForEach(u => _ctx.Paciente.Add(u));
                _ctx.SaveChanges();

                // Creación de Tipos de Cita
                var TipoCitas = new List<TipoCita>{
                    new TipoCita{Descripcion = "Prioritaria"},
                    new TipoCita{Descripcion = "Urgencias"},
                    new TipoCita{Descripcion = "Control"},
                    new TipoCita{Descripcion = "Pediatría"},
                    new TipoCita{Descripcion = "Oftalmología"},
                };

                TipoCitas.ForEach(u => _ctx.TipoCita.Add(u));
                _ctx.SaveChanges();

                // Creación de Citas
                var Citas = new List<Cita>{
                    new Cita{PacienteId = 1, Fecha = Convert.ToDateTime("21/10/2017"), TipoCitaId = 5},
                    new Cita{PacienteId = 2, Fecha = Convert.ToDateTime("22/10/2017"), TipoCitaId = 4},
                    new Cita{PacienteId = 3, Fecha = Convert.ToDateTime("23/10/2017"), TipoCitaId = 3},
                    new Cita{PacienteId = 4, Fecha = Convert.ToDateTime("24/10/2017"), TipoCitaId = 2},
                    new Cita{PacienteId = 5, Fecha = Convert.ToDateTime("25/10/2017"), TipoCitaId = 1},
                };

                Citas.ForEach(u => _ctx.Cita.Add(u));
                _ctx.SaveChanges();

            }
        }
    }

}

