﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using com.Citas.Datos.Models;
using Microsoft.Extensions.Configuration;

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using com.Citas.Datos.Data;


namespace com.Citas.Datos.Data
{
    public class CitaDbContext : DbContext, IDisposable
    {
        // Tablas BD
        public DbSet<Cita> Cita { get; set; }
        public DbSet<Paciente> Paciente { get; set; }
        public DbSet<TipoCita> TipoCita { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="modelBuilder"></param>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Cita>().ToTable("Cita");
            modelBuilder.Entity<Paciente>().ToTable("Paciente");
            modelBuilder.Entity<TipoCita>().ToTable("TipoCita");

            //IApplicationBuilder app;
            //var sampleData = ActivatorUtilities.CreateInstance<CitaContextInitialize>(app.ApplicationServices);
            //sampleData.InitializeData();

            //Seed();
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="optionsBuilder"></param>
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Data Source=TOSHIBA\SQLEXPRESS;Initial Catalog=Clinica;Persist Security Info=True;User ID=sa;Password=a");
          
        }

        /// <summary>
        /// 
        /// </summary>
        private void Seed()
        {
           
                //if (dataContext.Paciente.Count() == 0)
                //{
                //    // Creación de Pacientes
                //    var Pacientes = new List<Paciente>{
                //    new Paciente{Nombre = "Juan", Edad=32, Sexo="M"},
                //    new Paciente{Nombre = "Manuel", Edad=39, Sexo="M"},
                //    new Paciente{Nombre = "Felipe", Edad=49, Sexo="M"},
                //    new Paciente{Nombre = "Jair", Edad=17, Sexo="M"},
                //    new Paciente{Nombre = "Andrés", Edad=21, Sexo="M"},
                //};

                //    Pacientes.ForEach(u => dataContext.Paciente.Add(u));
                //    dataContext.SaveChanges();

                //    // Creación de Tipos de Cita
                //    var TipoCitas = new List<TipoCita>{
                //    new TipoCita{Descripcion = "Prioritaria"},
                //    new TipoCita{Descripcion = "Urgencias"},
                //    new TipoCita{Descripcion = "Control"},
                //    new TipoCita{Descripcion = "Pediatría"},
                //    new TipoCita{Descripcion = "Oftalmología"},
                //};

                //    TipoCitas.ForEach(u => dataContext.TipoCita.Add(u));
                //    dataContext.SaveChanges();

                //    // Creación de Citas
                //    var Citas = new List<Cita>{
                //    new Cita{PacienteId = 1, Fecha = Convert.ToDateTime("21/10/2017"), TipoCitaId = 5},
                //    new Cita{PacienteId = 2, Fecha = Convert.ToDateTime("22/10/2017"), TipoCitaId = 4},
                //    new Cita{PacienteId = 3, Fecha = Convert.ToDateTime("23/10/2017"), TipoCitaId = 3},
                //    new Cita{PacienteId = 4, Fecha = Convert.ToDateTime("24/10/2017"), TipoCitaId = 2},
                //    new Cita{PacienteId = 5, Fecha = Convert.ToDateTime("25/10/2017"), TipoCitaId = 1},
                //};

                //    Citas.ForEach(u => dataContext.Cita.Add(u));
                //    dataContext.SaveChanges();
                
            }
        }
    }


