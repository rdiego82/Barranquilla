﻿using System;
using System.Collections.Generic;
using System.Text;

namespace com.Citas.Entidades
{
    public class TipoCitaEntidad
    {
        public int Id { get; set; }
        public string Descripcion { get; set; }
        public List<CitaEntidad> Cita { get; set; }
    }
}
