﻿using System;

namespace com.Citas.Entidades
{
    public class CitaEntidad
    {
        public int Id { get; set; }
        public int? PacienteId { get; set; }
        public DateTime? Fecha { get; set; }
        public int? TipoCitaId { get; set; }

        public PacienteEntidad Paciente { get; set; }
        public TipoCitaEntidad TipoCita { get; set; }
    }
}
