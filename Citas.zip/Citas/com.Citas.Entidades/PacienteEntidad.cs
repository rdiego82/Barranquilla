﻿using System;
using System.Collections.Generic;
using System.Text;

namespace com.Citas.Entidades
{
    public class PacienteEntidad
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public int? Edad { get; set; }
        public string Sexo { get; set; }
        public List<CitaEntidad> Cita { get; set; }
    }
}
