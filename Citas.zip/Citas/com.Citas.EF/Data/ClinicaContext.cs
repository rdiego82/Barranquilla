﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using com.Citas.EF.Models;

namespace com.Citas.EF.Data
{
    public class ClinicaContext : DbContext
    {
        public DbSet<Cita> Cita { get; set; }
        public DbSet<Paciente> Paciente { get; set; }
        public DbSet<TipoCita> TipoCita { get; set; }

        public ClinicaContext()
        {          // << The reason....

        }

        public ClinicaContext(DbContextOptions<ClinicaContext> options) : base(options)
        {
        }
                
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            
        }

       
    }

}
