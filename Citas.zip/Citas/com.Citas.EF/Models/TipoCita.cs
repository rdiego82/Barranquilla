﻿using System;
using System.Collections.Generic;
using System.Text;

namespace com.Citas.EF.Models
{
    public class TipoCita
    {
        public int Id { get; set; }
        public string Descripcion { get; set; }

        public List<Cita> Cita { get; set; }
    }
}
