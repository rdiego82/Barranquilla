﻿using System;
using com.Citas.Datos.Data;
using com.Citas.Datos.Models;
using com.Citas.Datos.Repository;
using com.Citas.Entidades;
using System.Collections.Generic;
using System.Text;

namespace com.Citas.LN
{
    public class TipoCitaLN
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public TipoCita Consultar(string key)
        {
            var tipoCitaDatos = new TipoCitaDatos();
            return tipoCitaDatos.Consultar(key);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<TipoCita> Consultar()
        {
            var tipoCitaDatos = new TipoCitaDatos();
            return tipoCitaDatos.Consultar();
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="tipoCita"></param>
        /// <returns></returns>
        public bool Crear(TipoCita tipoCita)
        {
            var tipoCitaDatos = new TipoCitaDatos();
            return tipoCitaDatos.Crear(tipoCita);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="tipoCita"></param>
        /// <returns></returns>
        public bool Actualizar(TipoCita tipoCita)
        {
            var tipoCitaDatos = new TipoCitaDatos();
            return tipoCitaDatos.Actualizar(tipoCita);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="tipoCita"></param>
        /// <returns></returns>
        public bool Eliminar(TipoCita tipoCita)
        {
            var tipoCitaDatos = new TipoCitaDatos();
            return tipoCitaDatos.Eliminar(tipoCita);
        }
    }
}
