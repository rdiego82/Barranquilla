﻿using System;
using com.Citas.Datos.Data;
using com.Citas.Datos.Models;
using com.Citas.Datos.Repository;
using com.Citas.Entidades;
using System.Collections.Generic;
using System.Text;

namespace com.Citas.LN
{
    public class CitaLN
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public Cita Consultar(string key)
        {
            var citaDatos = new CitaDatos();
            return citaDatos.Consultar(key);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<Cita> Consultar()
        {
            var citaDatos = new CitaDatos();
            return citaDatos.Consultar();
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="cita"></param>
        /// <returns></returns>
        public bool Crear(Cita cita)
        {
            var citaDatos = new CitaDatos();
            return citaDatos.Crear(cita);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cita"></param>
        /// <returns></returns>
        public bool Actualizar(Cita cita)
        {
            var citaDatos = new CitaDatos();
            return citaDatos.Actualizar(cita);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cita"></param>
        /// <returns></returns>
        public bool Eliminar(Cita cita)
        {
            var citaDatos = new CitaDatos();
            return citaDatos.Eliminar(cita);
        }
    }
}
