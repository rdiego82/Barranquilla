﻿using com.Citas.Datos.Data;
using com.Citas.Datos.Models;
using com.Citas.Datos.Repository;
using com.Citas.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace com.Citas.LN
{
    public class PacienteLN
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public Paciente Consultar(string key)
        {
            var pacienteDatos = new PacienteDatos();
            return pacienteDatos.Consultar(key);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<Paciente> Consultar()
        {
            var pacienteDatos = new PacienteDatos();
            return pacienteDatos.Consultar();
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="paciente"></param>
        /// <returns></returns>
        public bool Crear(Paciente paciente)
        {
            var pacienteDatos = new PacienteDatos();
            return pacienteDatos.Crear(paciente);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="paciente"></param>
        /// <returns></returns>
        public bool Actualizar(Paciente paciente)
        {
            var pacienteDatos = new PacienteDatos();
            return pacienteDatos.Actualizar(paciente);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="paciente"></param>
        /// <returns></returns>
        public bool Eliminar(Paciente paciente)
        {
            var pacienteDatos = new PacienteDatos();
            return pacienteDatos.Eliminar(paciente);
        }

    }
}
