using com.Citas.Datos.Models;
using com.Citas.Datos.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace com.Citas.Datos.Tests
{

    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public Cita ConsultarCitas(string key)
        {

            var citaDatos = new CitaDatos();
            return citaDatos.Consultar(key);
        }

    }
}
