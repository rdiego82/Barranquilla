using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using com.Citas.LN;
using com.Citas.Entidades;
using com.Citas.Datos.Models;

namespace com.Citas.Rest.Controllers
{
    [Produces("application/json")]
    [Route("api/Pacientes")]
    public class PacientesController : Controller
    {
        // GET: api/Pacientes
        [HttpGet]
        public List<Paciente> consultarPacientes()
        {
            var pacienteLN = new PacienteLN(); 
            return pacienteLN.Consultar();
        }

        // POST: api/Pacientes
        [HttpPost]
        public bool Crear([FromBody]Paciente paciente)
        {
            var pacienteLN = new PacienteLN();
            return pacienteLN.Crear(paciente);
        }
        
        // PUT: api/Pacientes/5
        [HttpPut("{id}")]
        public bool Actualizar([FromBody]Paciente paciente)
        {
            var pacienteLN = new PacienteLN();
            return pacienteLN.Actualizar(paciente);
        }
        
        // DELETE: api/Pacientes/5
        [HttpDelete("{id}")]
        public bool Eliminar([FromBody]Paciente paciente)
        {
            var pacienteLN = new PacienteLN();
            return pacienteLN.Eliminar(paciente);
        }
    }
}
