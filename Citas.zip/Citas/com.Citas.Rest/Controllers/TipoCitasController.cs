using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using com.Citas.LN;
using com.Citas.Entidades;
using com.Citas.Datos.Models;

namespace com.Citas.Rest.Controllers
{
    [Produces("application/json")]
    [Route("api/TipoCitas")]
    public class TipoCitasController : Controller
    {
        // GET: api/TipoCitas
        [HttpGet]
        public List<TipoCita> consultarTipoCitas()
        {
            var tipoCitaLN = new TipoCitaLN();
            return tipoCitaLN.Consultar();
        }

        // POST: api/TipoCitas
        [HttpPost]
        public bool Crear([FromBody]TipoCita tipoCita)
        {
            var tipoCitaLN = new TipoCitaLN();
            return tipoCitaLN.Crear(tipoCita);
        }

        // PUT: api/TipoCitas/5
        [HttpPut("{id}")]
        public bool Actualizar([FromBody]TipoCita tipoCita)
        {
            var tipoCitaLN = new TipoCitaLN();
            return tipoCitaLN.Actualizar(tipoCita);
        }

        // DELETE: api/TipoCitas/5
        [HttpDelete("{id}")]
        public bool Eliminar([FromBody]TipoCita tipoCita)
        {
            var tipoCitaLN = new TipoCitaLN();
            return tipoCitaLN.Eliminar(tipoCita);
        }
    }
}
